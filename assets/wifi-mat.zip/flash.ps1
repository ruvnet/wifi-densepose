# WiFi-Mat v3.2 Flash Installer
# AI Thermal Monitor + WiFi CSI Sensing

param(
    [string]$Port = "COM7"
)

Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  WiFi-Mat v3.2 Flash Installer" -ForegroundColor White
Write-Host "  AI Thermal + WiFi CSI Presence Detection" -ForegroundColor Gray
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""

# Setup ESP-RS environment
$env:PATH = "$env:USERPROFILE\.rustup\toolchains\esp\bin;$env:USERPROFILE\.cargo\bin;$env:PATH"
$env:LIBCLANG_PATH = "$env:USERPROFILE\.rustup\toolchains\esp\xtensa-esp32-elf-clang\esp-18.1.2_20240912\esp-clang\lib"

# Check for espflash
$espflash = Get-Command espflash -ErrorAction SilentlyContinue
if (-not $espflash) {
    Write-Host "ERROR: espflash not found!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Install with: cargo install espflash" -ForegroundColor Yellow
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "Flashing to $Port..." -ForegroundColor Yellow
Write-Host "This takes about 60 seconds." -ForegroundColor Gray
Write-Host ""

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$firmware = Join-Path $scriptDir "wifi-mat.bin"

& espflash flash $firmware -p $Port --monitor

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "================================================" -ForegroundColor Green
    Write-Host "  Flash successful!" -ForegroundColor Green
    Write-Host ""
    Write-Host "  Display Modes (double-tap to cycle):" -ForegroundColor Cyan
    Write-Host "    STATS - Temperature and patterns"
    Write-Host "    GRAPH - Temperature history"
    Write-Host "    PTRNS - Pattern list"
    Write-Host "    ANOM  - Anomaly detection"
    Write-Host "    AI    - Power optimization"
    Write-Host "    CSI   - WiFi motion sensing (radar + breathing)"
    Write-Host "    RF    - Device detection"
    Write-Host "    INFO  - Device info"
    Write-Host ""
    Write-Host "  Visual Indicators:" -ForegroundColor Cyan
    Write-Host "    - Animated motion figure"
    Write-Host "    - Radar sweep with blips"
    Write-Host "    - Breathing waveform"
    Write-Host "    - Alert flash on detection"
    Write-Host "================================================" -ForegroundColor Green
}
