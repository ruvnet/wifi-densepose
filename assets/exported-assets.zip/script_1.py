# Install required packages
!pip install torch torchvision numpy scipy matplotlib
print("Packages installed successfully!")